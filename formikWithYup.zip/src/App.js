// import YoutubeForm from "./Components/YoutubeForm";

import PracticeFormikYup from "./Components/PracticeFormikYup";
import YoutubeFormWithYup from "./Components/YoutubeFormWithYup";

function App() {

  return (

    <div className='bg-blue-100 w-[100vw]  h-[100vh] flex flex-col justify-center items-center'>
      {/* <YoutubeForm/> */}
      {/* <YoutubeFormWithYup /> */}
      <PracticeFormikYup/>
    </div>
  );
}

export default App;
