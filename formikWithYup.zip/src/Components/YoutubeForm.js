import { useFormik } from 'formik'
import React from 'react'

const YoutubeForm = () => {
    const initialValues = {
        name: '',
        email: '',
        channel: '',
    };
    const onubmit = values => {
        console.log('after submiting form',values);
    };
    const validate = values => {
        let error = {};
        if (!values.name) {
            error.name = 'Required'
        };
        if (!values.email) {
            error.email = 'Required'
        }
        else if (!/^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+\.[a-zA-z]{2,3}$/i.test(values.email)) {
            error.email = 'not valid email....'
        }
        if (!values.channel) {
            error.channel = 'Required'
        }
        return error;
    };
    const formik = useFormik({
        initialValues,
        onsubmit,
        validate,
    })
    console.log('visited fields are :', formik.touched)
    console.log('form values are:', formik.values);
    return (
        <form className='flex  flex-col gap-8 bg-orange-700 p-4' onSubmit={formik.handleSubmit}>
            <div className='flex justify-between gap-2 flex-col'>
                <label htmlFor="name">Name</label>
                <input type="text" id='name' name='name' value={formik.values.name} onChange={formik.handleChange} onBlur={formik.handleBlur} />
                {formik.errors.name && formik.touched.name ? <div>{formik.errors.name}</div> : null}
            </div>
            <div className='flex justify-between gap-2 flex-col'>
                <label htmlFor="email">email</label>
                <input type="email" id='email' name='email' value={formik.values.email} onChange={formik.handleChange} onBlur={formik.handleBlur} />
                {formik.errors.email && formik.touched.email ? <div>{formik.errors.email}</div> : null}
            </div>
            <div className='flex justify-between gap-2 flex-col'>
                <label htmlFor="channel">channel</label>
                <input type="text" id='channel' name='channel' value={formik.values.channel} onChange={formik.handleChange} onBlur={formik.handleBlur} />
                {formik.errors.channel && formik.touched.channel ? <div>{formik.errors.channel}</div> : null}
            </div>
            <div className='flex justify-center items-center '>
                <button className='bg-blue-400 px-4 py-2 rounded' type='submit'>submit</button>
            </div>
        </form>
    )
}

export default YoutubeForm
