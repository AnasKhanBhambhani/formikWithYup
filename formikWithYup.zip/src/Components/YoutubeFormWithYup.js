import { useFormik } from 'formik'
import * as Yup from 'yup';
import React from 'react'

const YoutubeFormWithYup = () => {
    const initialValues = {
        name: '',
        email: '',
        channel: '',
    };
    const onSubmit = values => {
        console.log(values);
    };
    const validationSchema = Yup.object({
        name: Yup.string().required('required'),
        email: Yup.string().email('invalid Email...').required('required'),
        channel: Yup.string().required('required'),
    })
    const formik = useFormik({
        initialValues,
        onSubmit,
        validationSchema,
    })
    console.log('visited fields are :', formik.touched);
    console.log('form values are:', formik.values);
    return (
        <form className='flex  flex-col gap-8 bg-orange-700 p-4' onSubmit={formik.handleSubmit}>
            <div className='flex justify-between gap-2 flex-col'>
                <label htmlFor="name">Name</label>
                <input type="text" id='name' name='name'
                    {...formik.getFieldProps('name')} // instead of using value,onchange,onblur etc 
                />
                {formik.errors.name && formik.touched.name ? <div>{formik.errors.name}</div> : null}
            </div>
            <div className='flex justify-between gap-2 flex-col'>
                <label htmlFor="email">email</label>
                <input type="email" id='email' name='email'
                    {...formik.getFieldProps('email')}
                />
                {formik.errors.email && formik.touched.email ? <div>{formik.errors.email}</div> : null}
            </div>
            <div className='flex justify-between gap-2 flex-col'>
                <label htmlFor="channel">channel</label>
                <input type="text" id='channel' name='channel'
                    {...formik.getFieldProps('channel')}
                />
                {formik.errors.channel && formik.touched.channel ? <div>{formik.errors.channel}</div> : null}
            </div>
            <div className='flex justify-center items-center '>
                <button className='bg-blue-400 px-4 py-2 rounded' type='submit'>submit</button>
            </div>
        </form>
    )
}
export default YoutubeFormWithYup