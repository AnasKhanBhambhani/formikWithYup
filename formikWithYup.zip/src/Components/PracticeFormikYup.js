import React from 'react'
import { ErrorMessage, FastField, Field, FieldArray, Form, Formik } from 'formik'
import * as Yup from 'yup';
const PracticeFormikYup = () => {
  const initialValues = {
    name: '',
    email: '',
    channel: '',
    comments: '',
    address: '',
    social: {
      facebook: '',
      twitter: '',
    },
    phoneNumber: ['', ''],
    phoneNo: [''],
  }
  const onSubmit = values => {
    console.log(values);
  }
  const validationSchema = Yup.object({
    name: Yup.string().required('required'),
    email: Yup.string().email().required('required'),
    channel: Yup.string().required('required'),
    comments: Yup.string().required('required'),
    address: Yup.string().required('required'),
  })
  return (
    <Formik
      className='bg-emerald-200 p-7'
      initialValues={initialValues}
      onSubmit={onSubmit}
      validationSchema={validationSchema}
      validateOnChange={false}
      validateOnBlur={false}
    >
      { formik => {
        console.log('formik',formik);
        return (
          <Form className='flex flex-col gap-3'>
            <div>
              <Field type="text" id='name' name='name' placeholder='Enter  Your Name...' />
            </div>
            <ErrorMessage name='name' component='div' />
            <div>
              <Field type="email" id='email' name='email' placeholder='Enter  Your email...' />
            </div>
            <ErrorMessage name='email' />
            <div>
              <Field type="text" id='channel' name='channel' placeholder='Enter  Your channel...' />
            </div>
            <ErrorMessage name='channel' />
            <div className='form-control'>
              <Field as='textarea' id='comments' name='comments' placeholder='Enter  Your comments...' className='w-full' />
            </div>
            <div className='form-control'>
              <FastField name='address' >
                {(props) => {
                  // console.log(props);
                  const { field, form, meta } = props;
                  // console.log(form.error);
                  return (<div>
                    <input type="text" id='address' {...field} />
                    {meta.touched && meta.error ? <div>{meta.error}</div> : null}
                  </div>)
                }
                }
              </FastField>
            </div>
            <div className='form-control'>
              <Field type='text' id='facebook' name='social.facebook' placeholder='Enter your facebook account' />
            </div>
            <div className='form-control'>
              <Field type='text' id='twitter' name='social.twitter' placeholder='Enter your twitter account' />
            </div>
            <div className='form-control'>
              <Field type='text' id='primary-Ph' name='phoneNumber[0]' placeholder='Enter your primary-Phone no....' />
            </div>
            <div className='form-control'>
              <Field type='text' id='secondary-Ph' name='phoneNumber[1]' placeholder='Enter your secondary-phone no.....' />
            </div>
            <div className='form-control'>
              <FieldArray name='phoneNo' placeholder='Enter your phone no.....' >
                {(FieldArrayProps) => {
                  // console.log('FieldArrayProps', FieldArrayProps);
                  const { push, remove, form } = FieldArrayProps;
                  const { values } = form;
                  const { phoneNo } = values;
                  return (
                    <div>
                      {phoneNo.map((no, index) => (
                        <div key={index}>
                          <Field name={`phoneNo[${index}]`} />
                          {index > 0 && <button type='button' onClick={() => { remove(index) }}>-</button>}
                          <button type='button' onClick={() => { push('') }}>+</button>
                        </div>

                      ))
                      }
                    </div>
                  )
                }}
              </FieldArray>
            </div>
            <div>
              <button className='bg-blue-600 px-4 py-2 rounded' type='sumbit' disabled={!formik.isValid}>Submit</button>
              
            </div>
          </Form>
        )
      }}
    </Formik>
  )
}
export default PracticeFormikYup
